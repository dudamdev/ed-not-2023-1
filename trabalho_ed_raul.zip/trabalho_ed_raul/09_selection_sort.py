""" 
    ALGORITMO DE ORDENAÇÃO SELECTION SORT
    Isola (seleciona) o primeiro elemento da lista e, em seguida, encontra o menor valor no restante da lista.
    Se o valor encontrado for menor que o valor previamente selecionado, efetua a troca entre eles.
    Continuando, seleciona o segundo elemento da lista, buscando pelo menor valor das posições subsequentes.
    Faz a troca entre os dois valores, se necessário.
    O processo se repete até que o penúltimo elemento da lista seja isolado, comparado com o último e feita a troca entre eles, se for o caso
"""

def selection_sort(lista):

    global comps, trocas, passadas
    comps = trocas = passadas = 0
    
    # Loop que vai da primeira até a PENÚLTIMA posição
    for pos_sel in range(len(lista) - 1):

        passadas += 1

        # Encontra o menor valor da sublista à frente de pos_sel
        pos_menor = pos_sel + 1
        for pos in range(pos_sel + 2, len(lista)):
            # Se o valor encontrado na posição pos for MENOR que o valor da posição pos_menor,
            # então pos_menor passa a ser pos
            comps += 1
            if lista[pos] < lista[pos_menor]: pos_menor = pos

        # Compara os elementos das posições pos_menor e pos_sel.
        # Se o valor do primeiro for MENOR que o valor do segundo, efetua a troca
        comps += 1
        if lista[pos_menor] < lista[pos_sel]:
            lista[pos_menor], lista[pos_sel] = lista[pos_sel], lista[pos_menor]
            trocas += 1


import sys
sys.dont_write_bytecode = True  # Impede a criação do cache

from time import time
import tracemalloc

# from dados.emp10mil import empresas
# from dados.emp25mil import empresas
# from dados.emp50mil import empresas
from dados.emp100mil import empresas


tracemalloc.start()
hora_ini = time()
selection_sort(empresas)
hora_fim = time()
mem_atual, mem_pico = tracemalloc.get_traced_memory()

# print("Lista ordenada: ", empresas)
print(f'Tempo gasto: {round((hora_fim - hora_ini) * 1000, 2)}ms')
print(f'Pico de memória: {round(mem_pico / 1024 / 1024, 5)} MB')
print(f'Comparações: {comps}, trocas: {trocas}, passadas: {passadas}\n')

""" 
    ALGORITMO DE ORDENAÇÃO BUBBLE SORT
    Percorre a lista a ser ordenada em sucessivas passadas, trocando dois elementos adjacentes sempre que o segundo for MENOR que o primeiro.
    Efetua tantas passadas quanto necessárias, até que, na última passada, nenhuma troca seja efetuada
"""

def bubble_sort(lista):
    global comps, trocas, passadas
    comps = trocas = passadas = 0

    # Loop eterno, não sabemos quantas passadas serão necessárias
    while True:
        trocou = False
        passadas += 1
        
        # Percurso da lista, do primeiro ao PENÚLTIMO elemento, com acesso a cada posição
        for pos in range(len(lista) - 1):
            comps += 1
            
            # Se o número que está a frente na lista for MENOR do que o que está atrás, TROCA
            if lista[pos + 1 ] < lista[pos]:
                lista[pos + 1], lista[pos] = lista[pos], lista[pos + 1]
                trocou = True
                trocas += 1
        
        if not trocou:  # Não houve troca na passada
            break       # Interrompe o loop eterno; acabou


import sys
sys.dont_write_bytecode = True  # Impede a criação do cache

from time import time
import tracemalloc

# from dados.emp10mil import empresas
# from dados.emp25mil import empresas
# from dados.emp50mil import empresas
from dados.emp100mil import empresas


tracemalloc.start()
hora_ini = time()
bubble_sort(empresas)
hora_fim = time()
mem_atual, mem_pico = tracemalloc.get_traced_memory()

# print("Lista ordenada: ", empresas)
print(f'Tempo gasto: {round((hora_fim - hora_ini) * 1000, 2)}ms')
print(f'Pico de memória: {round(mem_pico / 1024 / 1024, 5)} MB')
print(f'Comparações: {comps}, trocas: {trocas}, passadas: {passadas}\n')
